# Archaeological_Catalogue_from_CSV_Spreadsheet
A template to create an archaeological catalogue from a spreadsheet using the LaTeX  `csvsimple` package. 

![Preview Archaeological Catalogue from CSV Spreadsheet](https://github.com/latex-ninja/Archaeological_Catalogue_from_CSV_Spreadsheet/blob/main/preview-archaeo-catalogue.png)


